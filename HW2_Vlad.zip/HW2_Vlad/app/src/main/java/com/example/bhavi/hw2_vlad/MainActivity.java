package com.example.bhavi.hw2_vlad;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView1 = (TextView) findViewById(R.id.textView3);
        TextView textView2 = (TextView) findViewById(R.id.textView4);
        Calendar cal = Calendar.getInstance();
        String date = new SimpleDateFormat("MMM d, yyyy").format(cal.getTime());
        textView1.setText(date);
        textView2.setText(date);
    }

}
